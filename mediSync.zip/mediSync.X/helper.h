#ifndef HELPER_H
#define HELPER_H
#include "CONFIG.h"

int ADC_Read(int channel);

void ADC_init(void);

void usePeripheral(int peripheral, int action);
void input_units_screen();
void input_volume_screen();
void input_time_screen();
void syringe_not_pushed_screen();

void input_valve_screen(char action);
void syringe_filling_screen();
void start_infusion_screen();
char *
ftoa(float f, int * status);

#endif