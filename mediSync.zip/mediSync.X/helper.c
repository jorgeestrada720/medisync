
#include "helper.h"
#include "CONFIG.h"
#include "lcd.h"
int ADC_Read(int channel)
{
    int digital;
    ADCON0 =(ADCON0 & 0b11000011)|((channel<<2) & 0b00111100);
    ADCON0 |= ((1<<ADON)|(1<<GO)); 
    while(ADCON0bits.GO_nDONE==1);
    digital = (ADRESH*256) | (ADRESL); 
    return(digital);
}

void ADC_init(void){
    //ANALOG READING PIN CONFIGURATION
    TRISA = 0xff; /*set as input port*/
    ADCON1 = 0x0e; /*ref vtg is VDD and Configure pin as analog pin*/
    ADCON2 = 0x92; /*Right Justified, 4Tad and Fosc/32. */
    ADRESH = 0; /*Flush ADC output Register*/
    ADRESL = 0;
}

void usePeripheral(int peripheral, int action){

    if(peripheral == green_led && action == on){
        LATA2 = on;
    }else if(peripheral == green_led && action == off){
        LATA2 = off;
    }else if(peripheral == orange_led && action == on){
        LATC6 = on;
    }else if(peripheral == orange_led && action == off){
        LATC7 = off;
    }
    else if(peripheral == red_led && action == on){
        LATC5 = on;
    }else if(peripheral == red_led && action == off){
        LATC5 = off;
    }else if(peripheral == buzzer && action == on){
        LATC4 = on;
    }else if(peripheral == buzzer && action == off){
        LATC4 = off;
    }

}

void input_units_screen(){
    int units;
    //INTERFACE
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("INPUT VOLUME (UNITS)");
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("INPUT VOLUME");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("1. ml");
    LCD_Goto(position_column_1, position_row_3);
    LCD_Print("2. cm3");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");

    
}

void input_volume_screen(){
    //INTERFACE VOLUME
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("INPUT V (AMOUNT)");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("V BETWEEN 0-10ML");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");

}

void input_time_screen(){

    //INTERFACE TIME 
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("INPUT TIME");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("T BETWEEN 0-15 MIN");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");

}

void syringe_not_pushed_screen(){

    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("SYRINGE IS NOT");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("PUSHED IN");
    __delay_ms(2000);
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("PUSHING");
}

void input_valve_screen(char action){
    //INTERFACE
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("DO YOU WANT TO");
    LCD_Goto(position_column_1, position_row_2);
    if(action == 'o'){
        LCD_Print("OPEN VALVE");
    }else if(action == 'c'){
        LCD_Print("CLOSE VALVE");
    }
    
    LCD_Goto(position_column_1, position_row_3);
    LCD_Print("1. YES");
    LCD_Goto(position_column_1, position_row_4);
    LCD_Print("2. NO");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");

}

void syringe_filling_screen(){
     //INTERFACE
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("DO YOU WANT TO");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("START FILLING");
    LCD_Goto(position_column_1, position_row_3);
    LCD_Print("1. YES");
    LCD_Goto(position_column_1, position_row_4);
    LCD_Print("2. NO");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");
}

void start_infusion_screen(){
    //INTERFACE
    LCD_Cmd(LCD_CLEAR);
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("DO YOU WANT TO");
    LCD_Goto(position_column_1, position_row_2);
    LCD_Print("START INFUSION?");
    LCD_Goto(position_column_1, position_row_3);
    LCD_Print("1. YES");
    LCD_Goto(position_column_1, position_row_4);
    LCD_Print("2. NO");
    LCD_Goto(position_column_17, position_row_4);
    LCD_Print("BACK");
}

char *
ftoa(float f, int * status)
{
	static char		buf[17];
	char *			cp = buf;
	unsigned long	l, rem;

	if(f < 0) {
		*cp++ = '-';
		f = -f;
	}
	l = (unsigned long)f;
	f -= (float)l;
	rem = (unsigned long)(f * 1e6);
	sprintf(cp, "%lu.%6.6lu", l, rem);
	return buf;
}





