#include "CONFIG.h"
#include "lcd.h"
#include "actuator.h"
#include "helper.h"
#include "servo.h"
#include "keypad.h"
#include <stdio.h>
#include <float.h>
 


uint16_t actuator_speed = 0;
#define  ADC_CHANNEL 0

void MSDelay(int n)
{
    for (; n > 0; n--)
    {
        __delay_ms(10);
    }
}

void system_init(){ 
    // set internal oscillator to 8MHz and using internal oscillator
    OSCCON = 0x72;
    // PORTD initial state
    PORTD  = 0x00;   
    // configure all PORTD pins as outputs
    TRISD  = 0x00; 
    // configure all PORTC pins as outputs
    TRISC  = 0x00; 
    //initialize LCD16x2 in 4-bit mode 
    LCD_Begin();       // initialize LCD module
    //initialize 4x4keypad
    InitKeypad();   
    //set TRISA2 as output
    
    TRISA2 = 0;  
    //Turn on Power LED
    
    
    //SERVO
    TRISCbits.RC1 = 0; //pin como salida servo1
    T0CON  = 0x80; //configuro el registro con preescaler 1:2             
    INTCONbits.GIE    = 1; //Habilito las interrupciones gloabales
    //INTCONbits.PEIE   = 1; //Habilito  interrupciones internas o de perifericos (ADC,USB,USART,ETC)
    INTCONbits.TMR0IE = 1; //habilito la interrupcion por TMR0  
    //TMR0_Init();

    
};



long  ms = 0;

long counter = 0;


  long X;
  long expectedX;
  long runTime = 750;
  long pauseTime = 4250;
  unsigned long lastTime;
  long diffX;

void startMotor(){ //starts at full duty and ramps down
  move_actuator(forward, 1023);
  __delay_ms(5);
  move_actuator(forward, 800);
  __delay_ms(5);
  move_actuator(forward, 800);
}

void stopMotor(){
    move_actuator(forward, 0);
}


int getVoltageFrom(void){ // read analog voltage from actuator into 0-1023 int
  ADC_init();
  int bitVol = ADC_Read(0);
  return bitVol; // * (5/1024);

}

long getExpected(void) {
    ms = counter;
    long expected = ((ms/1000)/10)*14 ;
    return expected;
}

void checkSpeed(){
  expectedX = getExpected();
  X = getVoltageFrom();
  diffX = expectedX - X;
  if (diffX > 0){
     runTime = runTime + 100;
     pauseTime = pauseTime -100;
  }
  else if(diffX > 15){
    runTime = runTime +500;
     pauseTime = pauseTime - 500;
  }
  else if(diffX > 10){
    runTime = runTime +300;
     pauseTime = pauseTime - 300;
  }
  else if(diffX > 5){
    runTime = runTime +200;
     pauseTime = pauseTime -200;
  }
  else if(diffX < 15){
    runTime = runTime -500;
     pauseTime = pauseTime + 500;
  }
  else if(diffX < 10){
    runTime = runTime -300;
     pauseTime = pauseTime + 300;
  }
  else if(diffX < 5){
    runTime = runTime -200;
     pauseTime = pauseTime + 200;
  }
   if(runTime <= 0){
    runTime = 100;
  }
}


void main() 
{
    system_init(); 
    char key;   
    //welcome_screen();
    LCD_Begin();  
    //used for printing volatile floats
    char * buf[20];
    int status;
    LCD_Goto(position_column_1, position_row_1);
    LCD_Print("T="); 
    while(1){
        startMotor();
        
        MSDelay(runTime/10);
        counter += runTime;

        stopMotor();
   
        MSDelay(pauseTime/10);
        counter += pauseTime;
        
        
        checkSpeed();

        //Time
        LCD_Goto(position_column_3, position_row_1);
        sprintf(buf, "%d", counter);
        LCD_Print(buf);
        //counter += 0.25;

        //analog reading
        LCD_Goto(position_column_1, position_row_2);
        int voltage = getVoltageFrom();
        sprintf(buf, "%d", voltage);
        LCD_Print(buf);
       
        //counter += 0.25;

        //Expected value
        LCD_Goto(position_column_6, position_row_2);
        int expectedVoltage = getExpected();
        sprintf(buf, "%d", expectedVoltage);
        LCD_Print(buf);
        //counter += 0.25;

        
        /*
        sprintf(buf, "%d", counter);
        LCD_Print("Time = ");
        LCD_Print(buf); */ 
    }  
    //ADCON1 = 0x0F;      //todos los pines del PORTA,PORTB como digitales 
}

